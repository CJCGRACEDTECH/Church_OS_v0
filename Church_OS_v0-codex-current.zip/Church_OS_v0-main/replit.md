# Church OS

A church management platform shell with role-based auth (Admin and Member), placeholder dashboards, and a clean SaaS UI.

**Milestone:** Pre-Sprint 1 app shell — stable, ready for GitHub main branch push.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port varies, proxied at /api)
- `pnpm --filter @workspace/church-os run dev` — run the frontend (port varies, proxied at /)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/scripts run seed` — seed demo church + users
- `pnpm --filter @workspace/scripts run seed:reset` — wipe and reseed from scratch
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `SESSION_SECRET` — secret for signing session cookies
- Optional env: `API_PROXY_TARGET` — override the frontend dev proxy target for `/api`; defaults to `http://127.0.0.1:8080`, which matches the current Replit workspace layout.
- Recommended env: `DEFAULT_SIGNUP_CHURCH_SLUG` — the church slug assigned to new self-service member signups.
- Required for OAuth redirects: `APP_BASE_URL` — frontend URL to return to after Google/Apple auth completes.
- Google OAuth env: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`
- Apple OAuth env: `APPLE_CLIENT_ID`, `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_PRIVATE_KEY`, `APPLE_REDIRECT_URI`
- Admin invite env: `ADMIN_INVITE_TTL_HOURS` (defaults to 72), optional `RESEND_API_KEY`, `INVITE_EMAIL_FROM`. Without Resend, invite links are logged by the API server for testing.

## Test Credentials

- Admin: `admin@churchos.test` / `Admin123!`
- Member: `member@churchos.test` / `Member123!`
- Church: CJC International

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui + wouter
- API: Express 5 with session-based auth (connect-pg-simple + express-session)
- DB: PostgreSQL + Drizzle ORM
- Passwords: bcryptjs (pure JS, no native compilation required)
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## What Currently Works

- Member signup with profile capture and automatic member-only role assignment
- Editable member CRM profile covering account, personal, emergency contact, and address details
- Member password change for email/password accounts
- Admin tiers: `minister` admins handle operational ministry tools, `pastor` admins add pastoral/prayer/giving-summary context, and `super_admin` admins get finance, role-management, settings, and system configuration access.
- Super Admins can manage database-backed admin feature permissions and send expiring admin invitations.
- Children Ministry v0 supports child registration, parent/guardian pickup contacts, active check-ins, pickup codes, and backend-authorized check-out.
- Admin login → `/admin` dashboard
- Member login → `/member` dashboard
- Invalid login → clear error message
- Logout → session destroyed, redirected to login
- Page refresh → session preserved (cookie + PostgreSQL session store)
- Protected routes — unauthenticated users redirected to login
- Role enforcement — members can't access `/admin/*`, admins redirected to their dashboard
- Backend admin enforcement via `/api/admin/access-check`
- Google/Apple OAuth route foundations with provider availability controlled by env configuration
- All placeholder module pages render without errors (Coming Soon UI)
- `/api/health` and `/api/db-health` endpoints

## What Is Intentionally Not Built Yet

- Members module (Sprint 2)
- Households module (Sprint 2)
- Services module (Sprint 3)
- Full Children Ministry classroom operations beyond v0 check-in
- Attendance tracking (Sprint 3)
- Giving / Stripe integration (future sprint)
- Reports (future sprint)
- AI features, SMS/email (future sprint)

## Where Things Live

- `lib/api-spec/openapi.yaml` — OpenAPI contract (source of truth)
- `lib/db/src/schema/churches.ts` — churches table
- `lib/db/src/schema/users.ts` — users table (with role: admin | member)
- `lib/db/src/schema/admin-permissions.ts` — per-admin feature permissions
- `lib/db/src/schema/admin-invitations.ts` — expiring, single-use admin invite records
- `lib/db/src/schema/children.ts` — children, guardians, child/guardian relationships, and check-in records
- `artifacts/api-server/src/routes/auth.ts` — login, /me, logout routes
- `artifacts/api-server/src/routes/admin.ts` — admin profile data, permission management, invitations
- `artifacts/api-server/src/routes/children-checkin.ts` — Children Ministry API
- `artifacts/api-server/src/routes/health.ts` — /health, /healthz, /db-health
- `artifacts/api-server/src/middlewares/auth.ts` — requireAuth, requireRole middleware
- `artifacts/api-server/src/lib/password.ts` — bcryptjs hash/verify helpers
- `artifacts/church-os/src/pages/login.tsx` — Login page
- `artifacts/church-os/src/pages/admin-dashboard.tsx` — Admin dashboard
- `artifacts/church-os/src/pages/member-dashboard.tsx` — Member dashboard
- `artifacts/church-os/src/pages/admin/` — Admin placeholder pages
- `artifacts/church-os/src/pages/member/` — Member placeholder pages
- `artifacts/church-os/src/components/auth-context.tsx` — AuthContext + ProtectedRoute
- `artifacts/church-os/src/components/AdminLayout.tsx` — Admin sidebar shell
- `artifacts/church-os/src/components/MemberLayout.tsx` — Member sidebar shell
- `artifacts/church-os/src/components/ComingSoonPage.tsx` — Reusable placeholder
- `artifacts/church-os/src/lib/roles.ts` — ROLES constants
- `artifacts/church-os/src/lib/routes.ts` — ADMIN_ROUTES, MEMBER_ROUTES
- `artifacts/church-os/src/lib/permissions.ts` — frontend permission keys used against backend-provided permission state
- `scripts/src/seed.ts` — Demo data seed script
- `docs/developer-handoff.md` — Full team handoff notes

## Architecture Decisions

- Session-based auth via express-session stored in PostgreSQL (connect-pg-simple), not JWT. Simpler, more secure for web.
- Sessions table (`user_sessions`) is created automatically on first API server start.
- Custom fetch has `credentials: "include"` so session cookies work across the Replit proxy.
- bcryptjs used instead of bcrypt (avoids native compilation issues in Replit's pnpm environment).
- Role-based routing is handled at the React level via ProtectedRoute + AuthContext.
- `connect-pg-simple` is externalized in esbuild config — it reads `table.sql` at runtime via `__dirname` which breaks when bundled.
- After login, `queryClient.setQueryData(getGetMeQueryKey(), user)` is called immediately to hydrate the auth cache without a second round-trip.

## User Preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After any OpenAPI spec change, always run codegen before using new types.
- `pnpm approve-builds` prompt is interactive; avoid packages with native build scripts (use bcryptjs not bcrypt).
- The `user_sessions` table is auto-created by connect-pg-simple on first startup.
- Sessions use `sameSite: "lax"` in development and `"strict"` in production.
- `connect-pg-simple` MUST remain in `build.mjs` externals — it reads `table.sql` at runtime.
- New self-service signups are always created as `member`; do not add admin role selection to frontend forms.
- To create the first admin safely, use the seed script or a trusted direct database update after the user exists.
- Admin tier assignment is backend/database managed through `users.admin_level`; use `minister`, `pastor`, or `super_admin`.
- Admin feature permissions are stored in `admin_permissions` and enforced by backend middleware. Use `/admin/admins` as a Super Admin to manage permissions.
- Admin invites are stored in `admin_invitations`; invite tokens are hashed in the database, expire, and are single-use.
- Giving details, reports, admin management, and system settings require explicit backend permissions. Keep giving details Super Admin-only unless a future finance role is added.
- For Replit OAuth, use your deployed public callback URLs in the provider consoles and matching env vars in Replit Secrets.
- Profile data now adds member-focused account and CRM columns on `users`; run the database push after pulling these changes into Replit.
- Admin management adds `admin_permissions` and `admin_invitations`; run the database push after pulling these changes into Replit.
- Children Ministry adds `children`, `parent_guardians`, `child_guardian_relationships`, and `checkin_records`; run the database push after pulling these changes into Replit.

## Children Ministry Testing

1. Log in as an admin with the `attendance_checkin` permission.
2. Open `/admin/check-in`.
3. Register a child with at least one parent/guardian contact.
4. Add another pickup contact from the child profile panel if needed.
5. Check the child in and confirm they appear under Active Check-ins with a pickup code.
6. Try checking out with a non-authorized contact; the backend should reject it.
7. Check out with an authorized pickup contact and confirm the active check-in clears.

## Admin Invitation Testing

1. Log in as the seeded Super Admin: `admin@churchos.test` / `Admin123!`.
2. Open `/admin/admins`.
3. Send an invite. If `RESEND_API_KEY` is not configured, copy the invite URL from API server logs.
4. Open `/admin/invite/:token`, create a password, and accept the invite.
5. Confirm the new admin lands on `/admin/profile` with the assigned title and permissions.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- See `docs/developer-handoff.md` for full team handoff notes and GitHub push commands
